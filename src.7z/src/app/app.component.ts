import { Component } from '@angular/core';
import { CommonService } from 'src/shared/services/common.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  // user: any;
  // menus: Object;

  // constructor(private common: CommonService, private http: HttpClient){}
  ngOnInit() { 
       
   }
}
