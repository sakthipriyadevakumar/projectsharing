import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
 
export const coreRoutes: Routes = [
  {
    path: '', component: HeaderComponent, outlet: 'header',
    // canActivate: [ TranslationGuard ],
  },
  {
    path: '', component: FooterComponent, outlet: 'footer',
    // canActivate: [ TranslationGuard ],
  }
];
