import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { CommonService } from 'src/shared/services/common.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  user: any;
  menus: Object;
  
  constructor(private common: CommonService, private http: HttpClient) { }
  ngOnInit() {
    this.common.logdetails.subscribe((user) => { this.user = user; console.log(user); });
    this.http.get('http://localhost:3200/menus').subscribe((menus) => {this.menus = menus;
  console.log(this.menus)});

   
  }
   
}
