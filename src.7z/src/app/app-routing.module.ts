import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './prelogin/login/login.component';

const routes: Routes = [
  // {
  //   path:'',  component: LoginComponent
  // },
  {
    path: 'prelogin', loadChildren: './prelogin/prelogin.module#PreloginModule'
  },
  {
    path: 'products', loadChildren: './product/product.module#ProductModule'
  },
  {
    path: '**', redirectTo: 'prelogin'
  }
];

@NgModule({
  // imports: [RouterModule.forRoot(routes, { useHash: true })],
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
