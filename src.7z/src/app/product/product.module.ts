import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/shared.module';

import { ProductRoutingModule} from './product-routing.module';
import { OrderComponent } from './order/order.component';  
import { FormsModule } from "@angular/forms";
import { CategoriesComponent } from './categories/categories.component'; 
// import {ScrollDispatchModule} from '@angular/cdk/scrolling';
@NgModule({
  declarations: [ OrderComponent, CategoriesComponent],
  imports: [
    CommonModule,
    ProductRoutingModule,
    FormsModule,
    SharedModule
     
     
  ],
  exports:[]
})
export class ProductModule { }
