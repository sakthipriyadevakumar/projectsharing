import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { DataService } from 'src/shared/services/data.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.scss'],
  encapsulation: ViewEncapsulation.Emulated
})
export class OrderComponent implements OnInit {
  cartdata: any;
  cart: any;
  total: any;
  delivery: any;
  finalAmt: void;

  constructor(private data: DataService) { }

  ngOnInit() {
    this.data.cast.subscribe((cart) => {
    this.cart = cart;
    console.log( this.cart);
    for(var i=0;i<this.cart.length;i++){
      localStorage.setItem('order length',this.cart.length);
      localStorage.setItem('order1',this.cart[0].name);
      localStorage.setItem('order2',this.cart[1].name);
    }
      
      // localStorage.setItem('name', data[0]['name']);
    });
    this.total = this.data.getTotal(this.cart);
    this.delivery = this.data.getdelivery(this.cart);
    this.finalAmt = this.data.getFinalAmount(this.delivery, this.cart, this.total);
  }

}
