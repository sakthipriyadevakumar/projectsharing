import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from 'src/shared/services/data.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from 'src/shared/services/common.service';

// import * as productJSON from '../../../assets/json/utils/product.json';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {
  products: any;
  card: any = [];
  cart: any;
  cartButton: Object;
  categories: any;
  filterProduct: [];
  newArr: any[];
  user: any;
 

  constructor(private router: Router, private data: DataService, private http: HttpClient, private common: CommonService) { }

  ngOnInit() {
    // this.products = productJSON['products'];
   
    this.http.get('http://localhost:3000/products').subscribe((data) => { this.products = data; console.log(this.products); });
    this.http.get('http://localhost:3000/button').subscribe((data) => { this.cartButton = data['label']; });
    this.http.get('http://localhost:3000/categories').subscribe((data) => {
      this.categories = data;
      console.log(this.categories);
      this.changeCateg(this.categories[2].key);
    });
   
    this.data.cast.subscribe((cart) => this.cart = cart);
    this.common.logdetails.subscribe((user) => { this.user = user; console.log(this.user); });
   
    console.log(this.cart);
  }

  addTocart(product) {
    console.log(product);
    this.card.push(product);
    console.log(this.card);

  }
  changeCateg(val) {
    console.log(val);
    this.newArr=[];
    for (var i = 0; i < this.products.length; i++) {
      if (val == this.products[i].key) {
        this.filterProduct = this.products[i];
        this.newArr.push(this.filterProduct);
        // this.products.push(this.filterProduct);
        console.log(this.filterProduct);
      }
    }

  }
  cartDet(card) {
    console.log(card);
    this.data.sendCartDetail(card);
    this.router.navigate(['/products/cartDetail/']);
  }
}
