import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { ProductListComponent } from './product-list/product-list.component';
import { CartdetailComponent } from './cartdetail/cartdetail.component';
import { OrderComponent } from './order/order.component';
import { FormsModule } from "@angular/forms"; 
import { CategoriesComponent } from './categories/categories.component';
// import  productJson    from './../assets/utils/product';
const routes: Routes = [
  {
    path: '', component: ProductListComponent
  },
  {
    path: 'cartDetail', component: CartdetailComponent
  },
  {
    path: 'order', component: OrderComponent
  },
  {
    path: 'categories', component: CategoriesComponent
  },
  {
    path:'**',redirectTo:''
  }
];

@NgModule({
  declarations:[ProductListComponent, CartdetailComponent],
  imports: [RouterModule.forChild(routes), CommonModule,
    SharedModule, FormsModule],
  exports: [RouterModule, ProductListComponent, CartdetailComponent]
})
export class ProductRoutingModule { }
