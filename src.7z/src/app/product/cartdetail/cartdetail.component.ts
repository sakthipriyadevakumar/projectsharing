import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/shared/services/data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cartdetail',
  templateUrl: './cartdetail.component.html',
  styleUrls: ['./cartdetail.component.scss']
})
export class CartdetailComponent implements OnInit {
  cart: any;  
  total: any = 0;
  constructor(private data: DataService, private router: Router) { }

  ngOnInit() {
    this.data.cast.subscribe((cart) => this.cart = cart);
    console.log(this.cart); 
    this.total = this.data.getTotal(this.cart); 
    
  } 
 

  goToCheckout(){ 
    this.data.cast.subscribe((cart) =>{
      this.cart = cart;
      console.log(this.cart);
      this.router.navigate(['/products/order'],cart);
    });
     
    
   
  }

}
