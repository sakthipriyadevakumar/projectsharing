import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  submitted: boolean = false;
  constructor(private formBuilder: FormBuilder, private http: HttpClient, private router: Router) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      name: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }


  onSubmit(form) {
    console.log(form);
    this.http.post('http://localhost:3400/user', { "name": form.name, "password": form.password, "status": 0 })
      .subscribe(
        data => {
          console.log("POST Request is successful ", data);
        
        },
        error => {
          console.log("Error", error);
        }

      );


    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }
  }
}



