import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonService } from 'src/shared/services/common.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  name: any;
  password: any;
  credential: any;
  lName: any;
  lPassword: any;
  user: any;
  constructor(private formBuilder: FormBuilder, private http: HttpClient, private router: Router, private common: CommonService) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      name: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }


  onSubmit(form) {
    console.log(form);
    this.name = form.name;  
    this.password = form.password;
    this.lName = localStorage.getItem('name');
    this.lPassword = localStorage.getItem('password');
    if ((this.lName == form.name) && (this.lPassword == form.password)) {
      alert("second time login");
      this.router.navigate(['/products/productlist']);
      this.common.getLoggedUser(form.name);
    } else {
      alert("first time login");
      this.http.get('http://localhost:3400/user?name=' + this.name + '&password=' + this.password)
        .subscribe(
          data => {
            console.log("GET Request ", data);
            
            if (data == null) {
              this.router.navigate(['/prelogin/**']);
            }
            else {              
              this.common.getLoggedUser(data[0]['name']);
              localStorage.setItem('name', data[0]['name']);
              localStorage.setItem('password', data[0]['password']);
              this.router.navigate(['/products/productlist']);
            }

          }
        );
    }
  }
}                                                               
