import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataService } from './data.service';
import { CommonService } from './common.service';

@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ],
  providers:[DataService, CommonService]
})
export class ServicesModule { }
