import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  private user = new BehaviorSubject<any>('');

  logdetails = this.user.asObservable(); 

  constructor() { }
  getLoggedUser(data){
    console.log(data);
    this.user.next(data);    
  }
}
