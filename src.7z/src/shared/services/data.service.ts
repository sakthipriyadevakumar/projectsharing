import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
@Injectable({
  providedIn: 'root'
})
export class DataService {

  private cart = new BehaviorSubject<any>(null);

  cast = this.cart.asObservable();
  castdata: any;
  total: any = 0;
  delivery: number;
  finalAmt: any;
  price: number;

  constructor() { }
  getTotal(cart) {
    console.log(cart); 

    for (var i = 0; i < cart.length; i++) { 
      if (cart[i].price) {
        console.log(cart[i].price);
        this.total += parseInt(cart[i].price);
        console.log(this.total);
      }
    }

    return this.total;
  }
  sendCartDetail(cartdata) {
    this.cart.next(cartdata);
    console.log(cartdata);
  }
  getdelivery(cart) {
    console.log(cart);
    for (var i = 0; i < cart.length; i++) {
      if (cart[i].price > 500) {
        this.delivery = 0;
        console.log(this.total);
      }
      this.delivery = 50;
    }

    return this.delivery;
  }
  getFinalAmount(delivery, cart, total) {
    for (var i = 0; i < cart.length; i++) {
      this.finalAmt = parseInt(total) + parseInt(delivery);
      console.log(this.finalAmt);
    } 
    return this.finalAmt;
  }




}
