import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'search',
    pure: false
})
export class search implements PipeTransform {

    public transform(value, searchText: string) {
        if (!searchText) return value;
        // term = term.toUpperCase();  


        return value.filter(it => {
            return (it['brand'].toLowerCase()).includes(searchText.toLowerCase()) || it['price'].includes(searchText);
        });
    }
}