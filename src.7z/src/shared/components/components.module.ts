import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { HeadercontentComponent } from './headercontent/headercontent.component';

@NgModule({
  declarations: [HeadercontentComponent ],
  imports: [
    CommonModule    
  ],
  exports:[HeadercontentComponent]
})
export class ComponentsModule { }
